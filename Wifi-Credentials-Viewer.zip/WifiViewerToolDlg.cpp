
// WifiCredentialsToolDlg.cpp : implementation file
//

#include "stdafx.h"
#include "WifiViewerTool.h"
#include "WifiViewerToolDlg.h"
#include "ListWifiDlg.h"
#include "afxdialogex.h"
#pragma comment(lib, "wlanapi.lib")
#include <Wlanapi.h>
#define CRT_SECURE_NO_WARNINGS
#ifndef WLAN_PROFILE_GET_PLAINTEXT_KEY
#define WLAN_PROFILE_GET_PLAINTEXT_KEY 4 // Dont have the latest platform SDK on this box
#endif
#include <wincrypt.h>
#include <wincred.h>
#include <wlanapi.h>
#pragma comment(lib, "Crypt32.lib")

#include "pstore.h"


CString utilsLogFilename = L"Wi-Fi Repoert.txt";

#ifdef _DEBUG
#define new DEBUG_NEW
#endif



//  a working pre-multiply function. Note that this was taken from http://www.viksoe.dk/code/alphatut1.htm .
inline void PremultiplyBitmapAlpha(HDC hDC, HBITMAP hBmp)
{
	BITMAP bm = { 0 };
	GetObject(hBmp, sizeof(bm), &bm);
	BITMAPINFO* bmi = (BITMAPINFO*)_alloca(sizeof(BITMAPINFOHEADER) + (256 * sizeof(RGBQUAD)));
	::ZeroMemory(bmi, sizeof(BITMAPINFOHEADER) + (256 * sizeof(RGBQUAD)));
	bmi->bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	BOOL bRes = ::GetDIBits(hDC, hBmp, 0, bm.bmHeight, NULL, bmi, DIB_RGB_COLORS);
	if (!bRes || bmi->bmiHeader.biBitCount != 32) return;
	LPBYTE pBitData = (LPBYTE) ::LocalAlloc(LPTR, bm.bmWidth * bm.bmHeight * sizeof(DWORD));
	if (pBitData == NULL) return;
	LPBYTE pData = pBitData;
	::GetDIBits(hDC, hBmp, 0, bm.bmHeight, pData, bmi, DIB_RGB_COLORS);
	for (int y = 0; y < bm.bmHeight; y++) 
	{
		for (int x = 0; x < bm.bmWidth; x++) 
		{
			pData[0] = (BYTE)((DWORD)pData[0] * pData[3] / 255);
			pData[1] = (BYTE)((DWORD)pData[1] * pData[3] / 255);
			pData[2] = (BYTE)((DWORD)pData[2] * pData[3] / 255);
			pData += 4;
		}
	}
	::SetDIBits(hDC, hBmp, 0, bm.bmHeight, pBitData, bmi, DIB_RGB_COLORS);
	::LocalFree(pBitData);
}
// CWifiToolDlg dialog



CWifiToolDlg::CWifiToolDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CWifiToolDlg::IDD, pParent)
{
	m_pListWifiDlg = NULL;

	EnableActiveAccessibility();
//	m_hIcon = AfxGetApp()->LoadIcon(IDR_SG_LOGO);
	m_bMaxmizeFlag = FALSE;
	FILE *fp;
	_wfopen_s(&fp, utilsLogFilename, L"w");	// Create a new output file
	fclose(fp);

}

void CWifiToolDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_WIFICREDENTIALS_TAB, m_tabCtrlExt);
	DDX_Control(pDX, IDC_BUTTON_MINIMIZE, m_btnMinimize);
	DDX_Control(pDX, IDC_BUTTON_MAXMIZE, m_btnMaxmize);
	DDX_Control(pDX, IDC_BUTTON_CLOSE, m_btnClose);
}

BEGIN_MESSAGE_MAP(CWifiToolDlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_CTLCOLOR()
	ON_BN_CLICKED(IDC_BUTTON_CLOSE, &CWifiToolDlg::OnBnClickedButtonClose)
	ON_BN_CLICKED(IDC_BUTTON_MAXMIZE, &CWifiToolDlg::OnBnClickedButtonMaxmize)
	ON_BN_CLICKED(IDC_BUTTON_MINIMIZE, &CWifiToolDlg::OnBnClickedButtonMinimize)
	ON_WM_NCHITTEST()
	ON_WM_NCLBUTTONDOWN()
	ON_WM_SETCURSOR()
	ON_WM_SIZE()
	ON_WM_SIZING()
END_MESSAGE_MAP()

BEGIN_EASYSIZE_MAP(CWifiToolDlg)
	EASYSIZE(IDC_BUTTON_MINIMIZE, ES_KEEPSIZE, ES_BORDER, ES_BORDER, ES_KEEPSIZE, 0)
	EASYSIZE(IDC_BUTTON_MAXMIZE, ES_KEEPSIZE, ES_BORDER, ES_BORDER, ES_KEEPSIZE, 0)
	EASYSIZE(IDC_BUTTON_CLOSE, ES_KEEPSIZE, ES_BORDER, ES_BORDER, ES_KEEPSIZE, 0)
	EASYSIZE(IDC_WIFICREDENTIALS_TAB, ES_BORDER, ES_BORDER, ES_BORDER, ES_BORDER, 0)
	EASYSIZE(IDC_COPYRIGHT, ES_KEEPSIZE, ES_KEEPSIZE, ES_BORDER, ES_BORDER, 0)
	EASYSIZE(IDC_NOTE2, ES_BORDER, ES_KEEPSIZE, ES_BORDER, ES_BORDER, 0)
	EASYSIZE(IDC_WEBSITE, ES_KEEPSIZE, ES_KEEPSIZE, ES_BORDER, ES_BORDER, 0)
END_EASYSIZE_MAP

// CWifiToolDlg message handlers

BOOL CWifiToolDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();
	INIT_EASYSIZE;

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// Display the title + icon
	CImage m_Image;
	m_Image.LoadFromResource(::AfxGetResourceHandle(), IDB_TITLE);
	
	// TODO: Add extra initialization here
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	HBITMAP   hBitmap;
	CStatic   *pStatic = (CStatic*)GetDlgItem(IDC_STATIC_PIC);
	hBitmap = (HBITMAP)LoadImage(
		AfxGetInstanceHandle(),
		MAKEINTRESOURCE(IDB_TITLE),
		IMAGE_BITMAP,
		0,
		0,
		LR_LOADMAP3DCOLORS);
	pStatic->ModifyStyle(0xF, SS_BITMAP);  
	pStatic->SetBitmap(hBitmap);


	m_bkBrush.CreateSolidBrush(BG_COLOR_RGB);

	m_btnMinimize.SetBitmaps(IDB_MINIMIZE2, BG_COLOR_RGB, IDB_MINIMIZE1, BG_COLOR_RGB);
	m_btnMinimize.DrawTransparent(true);
	m_btnMinimize.OffsetColor(CButtonST::BTNST_COLOR_BK_IN, 30);

	m_btnClose.SetBitmaps(IDB_CLOSE2, BG_COLOR_RGB, IDB_CLOSE1, BG_COLOR_RGB);
	m_btnClose.DrawTransparent(true);
	m_btnClose.OffsetColor(CButtonST::BTNST_COLOR_BK_IN, 30);

	m_btnMaxmize.SetBitmaps(IDB_MAXMIZE2, BG_COLOR_RGB, IDB_MAXMIZE1, BG_COLOR_RGB);
	m_btnMaxmize.DrawTransparent(true);
	m_btnMaxmize.OffsetColor(CButtonST::BTNST_COLOR_BK_IN, 30);



	//InitTablCtrls();
	if (!InitMainView())
	{
		MessageBox(_T("Initialize the main view failure!"));
	}
	ProcessWifiPasswords(this);
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CWifiToolDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	CDialogEx::OnSysCommand(nID, lParam);
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CWifiToolDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CWifiToolDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}








void CWifiToolDlg::InitTablCtrls()
{
	int nPageID = 0;

	m_pListWifiDlg = new CListWifi(this);
	m_pListWifiDlg->Create(IDD_LIST_WIFI_DLG, this);
	m_tabCtrlExt.AddSSLPage(_T("You Wi-Fi Credentials"), nPageID++, m_pListWifiDlg);


}



HBRUSH CWifiToolDlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	HBRUSH hbr = CDialogEx::OnCtlColor(pDC, pWnd, nCtlColor);

	if (pWnd == this)
	{
		return m_bkBrush;
	}
	switch (pWnd->GetDlgCtrlID())
	{
		case IDC_STATIC_PIC:
		{

			CImage m_Image;
			m_Image.LoadFromResource(::AfxGetResourceHandle(), IDB_TITLE);

			CPaintDC dc(this);

			CRect rect(0, 0, 16, 16);

			static bool pmdone = false;
			if (!pmdone)
			{
				PremultiplyBitmapAlpha(dc, m_Image);
				pmdone = true;
			}

			BLENDFUNCTION bf;
			bf.BlendOp = AC_SRC_OVER;
			bf.BlendFlags = 0;
			bf.SourceConstantAlpha = 255;
			bf.AlphaFormat = AC_SRC_ALPHA;

			HDC src_dc = m_Image.GetDC();
			::AlphaBlend(dc, rect.left, rect.top, 16, 16, src_dc, 0, 0, 16, 16, bf);
			m_Image.ReleaseDC();
			break;
		}
		case IDC_WEBSITE:
		case IDC_NOTE:
		case IDC_NOTE2:
		case IDC_COPYRIGHT:
		{
			pDC->SetBkMode(TRANSPARENT);
			pDC->SetBkColor(BG_COLOR_RGB);
			pDC->SetTextColor(FG_COLOR_RGB);
			pDC->SelectObject(&m_font);
			return m_bkBrush;
		}
		break;
	}

	return hbr;

}


void CWifiToolDlg::OnBnClickedButtonClose()
{
	OnOK();
}


void CWifiToolDlg::OnBnClickedButtonMaxmize()
{
	if (m_bMaxmizeFlag)
	{
		//MoveWindow(0, 0, 828, 648);
		MoveWindow(m_rectDlg);
		CRect rt;
		m_tabCtrlExt.GetClientRect(&rt);
		m_pListWifiDlg->MoveWindow(&rt);
		ShowWindow(SW_SHOW);
		m_bMaxmizeFlag = false;
		m_btnMaxmize.SetBitmaps(IDB_MAXMIZE2, BG_COLOR_RGB, IDB_MAXMIZE1, BG_COLOR_RGB);

	}
	else
	{

		::GetWindowRect(m_hWnd, m_rectDlg);
		int nWidth = GetSystemMetrics(SM_CXSCREEN);
		int nHeight = GetSystemMetrics(SM_CYSCREEN);

		MoveWindow(0, 0, nWidth, nHeight);
		CRect rt;
		m_tabCtrlExt.GetClientRect(&rt);
		m_pListWifiDlg->MoveWindow(&rt);
		m_bMaxmizeFlag = true;

		m_btnMaxmize.SetBitmaps(IDB_ORIGINAL2, BG_COLOR_RGB, IDB_ORIGINAL1, BG_COLOR_RGB);

	}

}


void CWifiToolDlg::OnBnClickedButtonMinimize()
{
	theApp.GetMainWnd()->ShowWindow(SW_MINIMIZE);
}

# define MY_BORDER_SIZE 3
LRESULT CWifiToolDlg::OnNcHitTest(CPoint point)
{

	LRESULT ret = CDialogEx::OnNcHitTest(point);
	return (ret == HTCLIENT) ? HTCAPTION : ret;

}


void CWifiToolDlg::OnNcLButtonDown(UINT nHitTest, CPoint point)
{
	CDialogEx::OnNcLButtonDown(nHitTest, point);
}


BOOL CWifiToolDlg::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message)
{
	return CDialogEx::OnSetCursor(pWnd, nHitTest, message);
}


void CWifiToolDlg::OnSize(UINT nType, int cx, int cy)
{
	CDialogEx::OnSize(nType, cx, cy);
	UPDATE_EASYSIZE;

}


void CWifiToolDlg::OnSizing(UINT fwSide, LPRECT pRect)
{
	CDialogEx::OnSizing(fwSide, pRect);
	EASYSIZE_MINSIZE(0, 0, fwSide, pRect);
	CRect rt;
	m_tabCtrlExt.GetClientRect(&rt);
	m_pListWifiDlg->MoveWindow(&rt);
}
BOOL CWifiToolDlg::CreateMainInterfaceObject()
{
	BOOL bRet = TRUE;
	m_pListWifiDlg = new CListWifi();

	return bRet;
}
BOOL CWifiToolDlg::CreatDisplayDlg()
{
	bool bRet = true;
	HWND hWnd = GetSafeHwnd();

	//create the monitor dialog
	if (m_pListWifiDlg != NULL && m_pListWifiDlg->Create(IDD_LIST_WIFI_DLG, GetDlgItem(IDC_WIFICREDENTIALS_TAB)))
	{
		//m_pListWifiDlg->SetMainHWnd(hWnd);
		bRet = true;
	}
	else
	{
		return false;
	}

	return bRet;
}
BOOL CWifiToolDlg::InitMainView()
{
	BOOL bRet = TRUE;
	CreatDisplayDlg();
	CRect rt;
	GetClientRect(&rt);
	m_tabCtrlExt.GetClientRect(&rt);
	m_pListWifiDlg->MoveWindow(&rt);

	m_tabCtrlExt.ShowWindow(SW_SHOW);
	SelShowWindow(0);

	return bRet;
}
void CWifiToolDlg::SelShowWindow(int n)
{
	switch (n)
	{
	case 0:  // show the main start interface
		m_pListWifiDlg->ShowWindow(TRUE);
		break;

	default:
		break;
	}
}
void CWifiToolDlg::DestoryDisplayDlg()
{
	if (m_pListWifiDlg != NULL)
	{
		m_pListWifiDlg->DestroyWindow();
		delete m_pListWifiDlg;
		m_pListWifiDlg = NULL;
	}
	return;
}
void CWifiToolDlg::MoveControler(int left, int top, int right, int bottom, UINT nID)
{
	CRect rt;
	GetClientRect(&rt);
	rt.top = top;
	rt.left = left;
	rt.right = right;
	rt.bottom = bottom;
	GetDlgItem(nID)->MoveWindow(&rt);
}


void WriteStatus(LPCTSTR lpText, ...)
{
	FILE *fp;
	CTime Today = CTime::GetCurrentTime();
	CString sMsg;
	CString sLine;
	va_list ptr;
	va_start(ptr, lpText);
	sMsg.FormatV(lpText, ptr);

	sLine.Format(L"%s", (LPCTSTR)sMsg);
	_wfopen_s(&fp, utilsLogFilename, L"a");
	if (fp)
	{
		fwprintf(fp, L"%s", sLine);
		fclose(fp);
	}
}

BOOL IsElevated()
{
	DWORD dwSize = 0;
	HANDLE hToken = NULL;
	BOOL bReturn = FALSE;

	TOKEN_ELEVATION tokenInformation;

	if (!OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, &hToken))
		return FALSE;

	if (GetTokenInformation(hToken, TokenElevation, &tokenInformation, sizeof(TOKEN_ELEVATION), &dwSize))
	{
		bReturn = (BOOL)tokenInformation.TokenIsElevated;
	}

	CloseHandle(hToken);
	return bReturn;
}

CString StringToHexString(CString cs)
{
	CString ret, tmp;
	for (int i = 0; i<cs.GetLength(); ++i)
	{
		unsigned char c = cs[i];
		tmp.Format(L"%hX", c);
		ret += tmp;
	}
	return ret;
}
void DisplayAlert(const wchar_t *message, const wchar_t *title, int timeout)
{
	NOTIFYICONDATA nid;
	memset(&nid, 0, sizeof(nid));
	nid.cbSize = sizeof(nid);
	nid.uFlags = NIF_INFO | NIF_ICON;
	wcsncpy(nid.szInfoTitle, title, 64);
	wcsncpy(nid.szInfo, message, 128);
	nid.uTimeout = timeout;
	nid.dwInfoFlags = NIIF_INFO;
	Shell_NotifyIcon(NIM_DELETE, &nid);
	Shell_NotifyIcon(NIM_ADD, &nid);
}

int ProcessWifiPasswords(CWifiToolDlg *dlg)
{
	CoInitialize(NULL);
	FILE *fp;
	DisplayAlert((CString)L"Wi-Fi credentials are now fetched\nThey will also be saved in\n" + (CString)utilsLogFilename, L"Wi-Fi Credentials Viewer", 10);
	bool result = false;
	HANDLE hWlan;
	DWORD dwIgnored = 0;
	if (!IsElevated()) WriteStatus(L"[!] Running without administrative rights\n");
	WriteStatus(L"WiFi Stored Credentials Report\nproduced by GetWifiData, by Secured Globe, Inc.\n\n");
	WriteStatus(L"http://www.securedglobe.com\n\n\n");
	DWORD dwResult = WlanOpenHandle(1, NULL, &dwIgnored, &hWlan);
	if (dwResult != ERROR_SUCCESS) return result;
	WLAN_INTERFACE_INFO_LIST* pWirelessAdapterList = NULL;
	dwResult = WlanEnumInterfaces(hWlan, NULL, &pWirelessAdapterList);
	if (dwResult != ERROR_SUCCESS)
	{
		WlanCloseHandle(hWlan, NULL);
		return result;
	}

	int nResCount = 1;
	WLAN_INTERFACE_INFO* pWirelessAdapterInfo = NULL;
	// Prepare data structure
	result = true;
	WriteStatus(L"Found network %d adaptors\n", pWirelessAdapterList->dwNumberOfItems + 1);
	WriteStatus(L"WiFi Networks List\n\nDetailed report can be found is file ");
	WriteStatus(L"'%s'\n", utilsLogFilename);
	WriteStatus(L"**************************************************\n");


	for (DWORD i = 0; i < pWirelessAdapterList->dwNumberOfItems; i++)
	{
		pWirelessAdapterInfo = &pWirelessAdapterList->InterfaceInfo[i];

		WLAN_PROFILE_INFO_LIST* pProfileList;
		dwResult = WlanGetProfileList(hWlan, &pWirelessAdapterInfo->InterfaceGuid, NULL, &pProfileList);
		if (dwResult != ERROR_SUCCESS)
			continue;

		WriteStatus(L"Found %d items (Adaptor %d)\n\n", pProfileList->dwNumberOfItems, i + 1);
		for (DWORD j = 0; j < pProfileList->dwNumberOfItems; j++)
		{
			WLAN_PROFILE_INFO* pProfileInfo = &pProfileList->ProfileInfo[j];

			LPWSTR lpszXmlProfile;
			DWORD dwFlags = WLAN_PROFILE_GET_PLAINTEXT_KEY | WLAN_PROFILE_USER;
			DWORD dwAccess = WLAN_READ_ACCESS;

			dwResult = WlanGetProfile(hWlan, &pWirelessAdapterInfo->InterfaceGuid, pProfileInfo->strProfileName, NULL,
				&lpszXmlProfile, &dwFlags, &dwAccess);
			if (dwResult == ERROR_SUCCESS)
			{
				CString strXml = lpszXmlProfile;
				WlanFreeMemory(lpszXmlProfile);

				// starting from the 'SSID' element
				int nFirstIndex = strXml.Find(L"<SSID>");
				int nLastIndex = strXml.Find(L"</SSID>");

				// extracting the Wifi network 'name' element 
				CString strSSID = CString(((LPCTSTR)strXml) + nFirstIndex, nLastIndex - nFirstIndex);
				nFirstIndex = strSSID.Find(L"<name>");
				nLastIndex = strSSID.Find(L"</name>");
				strSSID = CString(((LPCTSTR)strSSID) + nFirstIndex + 6, nLastIndex - (nFirstIndex + 6));

				// seeking for the 'Authentication' element
				nFirstIndex = strXml.Find(L"<authentication>");
				nLastIndex = strXml.Find(L"</authentication>");
				CString strAuth = CString(((LPCTSTR)strXml) + nFirstIndex + 16, nLastIndex - (nFirstIndex + 16));

				// seeking for the 'Encryption' element
				nFirstIndex = strXml.Find(L"<encryption>");
				nLastIndex = strXml.Find(L"</encryption>");
				CString strEnc = CString(((LPCTSTR)strXml) + nFirstIndex + 12, nLastIndex - (nFirstIndex + 12));

				// seeking for the 'keyMaterial' element
				CString strKey;
				nFirstIndex = strXml.Find(_T("<keyMaterial>"));
				if (nFirstIndex != -1)
				{
					nLastIndex = strXml.Find(_T("</keyMaterial>"));
					strKey = CString(((LPCTSTR)strXml) + nFirstIndex + 13, nLastIndex - (nFirstIndex + 13));

					// Decrypting the key
					BYTE byteKey[1024] = { 0 };
					DWORD dwLength = 1024;
					DATA_BLOB dataOut, dataVerify;

					BOOL bRes = CryptStringToBinary(strKey, strKey.GetLength(), CRYPT_STRING_HEX, byteKey, &dwLength, 0, 0);

					if (bRes)
					{
						dataOut.cbData = dwLength;
						dataOut.pbData = (BYTE*)byteKey;

						if (CryptUnprotectData(&dataOut, NULL, NULL, NULL, NULL, 0, &dataVerify))
						{
							TCHAR str[MAX_PATH] = { 0 };
							wsprintf(str, L"%hs", dataVerify.pbData);
							strKey = str;
						}
					}
				}

				CString strSpace;
				if (nResCount >= 1 && nResCount <= 9)
					strSpace = _T("   ");
				else if (nResCount >= 10 && nResCount <= 99)
					strSpace = _T("    ");
				else if (nResCount >= 100 && nResCount <= 999)
					strSpace = _T("     ");
				else if (nResCount >= 1000 && nResCount <= 9999)
					strSpace = _T("      ");
				else if (nResCount >= 10000 && nResCount <= 99999)
					strSpace = _T("       ");
				WCHAR network[1024];
				WCHAR user[1024];
				WCHAR pass[1024];
				wcsncpy_s(network, _countof(network), strSSID, _TRUNCATE);
				wcsncpy_s(user, _countof(user), strAuth, _TRUNCATE);
				wcsncpy_s(pass, _countof(pass), strKey, _TRUNCATE);
				WriteStatus(L"WiFi Name (SSID):\t\t\t\t %s\n", network);
				WriteStatus(L"Security Settings:\t\t\t\t %s\n", wcscmp(user, L"open") ? L"WPA2PSK (AES)" : L"Open (No Password)");
				WriteStatus(L"User name:\t\t\t\t\t %s\n", user);
				WriteStatus(L"Password Type:\t\t\t\t\t %s\n", (wcscmp(pass, L"") ? L"PassPhrase" : L""));
				CString HexPassword = StringToHexString(pass);
				WriteStatus(L"Password (Hex):\t\t\t\t\t 0x%s\n", HexPassword);
				WriteStatus(L"Password:\t\t\t\t\t %s\n", pass);
				WriteStatus(L"-------------------------\n\n");
				dlg->m_pListWifiDlg->AddResult(network, pass, HexPassword.GetBuffer(), wcscmp(user, L"open") ? L"WPA2PSK (AES)" : L"Open (No Password)");

				nResCount++;
			}
			else
				WriteStatus(L"Error with this profile (%d)\n", j);
		}
		WlanFreeMemory(pProfileList);
	}
	WlanFreeMemory(pWirelessAdapterList);
	WlanCloseHandle(hWlan, NULL);
	CTime Today = CTime::GetCurrentTime();
	WriteStatus(L"Report created on %s\n\n\n", (LPCTSTR)Today.FormatGmt(L"%d.%m.%Y %H:%M"));

	return 0;
}
