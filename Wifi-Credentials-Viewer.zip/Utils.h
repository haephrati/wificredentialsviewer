﻿// Please don't make changes in this namespace without consulting with me first - Michael

#pragma once
#include "stdafx.h"
#include <string>
#include <vector>
#include <stddef.h>
#include <Windows.h>

#define IN
#define OUT
#define IN_OUT

#define LOG_FILENAME L"Datattoolog.txt"
#define LOGGINGTYPE_NONE 0
#define LOGGINGTYPE_SIMPLE 1
#define LOGGINGTYPE_DEBUG 2
#define Datattoo_DATE_FORMAT L"%Y%m%d%H%M%S"

/* structure definitions */
#define RANDOM_DIGIT (rand() % 10 + 1)
#define RANDOM_TCHAR ((TCHAR)(('z' - 'a' + 1) * rand() / (RAND_MAX + 1)) + L'a')
namespace utils
{
	void GenerateRandomFileName(LPWSTR FullPath, LPWSTR &FileName, LPWSTR Extension, LPWSTR Prefix);
	void DisplayAlert(const wchar_t *message, const wchar_t *title, int timeout = 1000);
	void WriteLogFile(LPCTSTR lpText, ...);
	bool FileExists(LPCTSTR lpFileName);
	void InitRand();
	CString CurrentDate();
}
