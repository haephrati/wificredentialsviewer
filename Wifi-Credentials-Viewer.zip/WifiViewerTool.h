
// WifiCredentialsTool.h : main header file for the Wifi Credentials Viewer application
//

#pragma once
#include "WifiViewerToolDlg.h"
#ifndef __AFXWIN_H__
	#error "include 'stdafx.h' before including this file for PCH"
#endif

#include "resource.h"		// main symbols


// CWifiCredentialsToolApp:
// See WifiCredentialsToolApp.cpp for the implementation of this class
//

class CWifiCredentialsToolApp : public CWinApp
{
public:
	CWifiCredentialsToolApp();

// Overrides
public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();

// Implementation

	DECLARE_MESSAGE_MAP()
};

extern CWifiCredentialsToolApp theApp;
