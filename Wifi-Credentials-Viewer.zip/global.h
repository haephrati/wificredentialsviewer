#ifndef __WIFICREDENTIALS_GLOBAL_H__
#define __WIFICREDENTIALS_GLOBAL_H__

#include "stdafx.h"


#endif /*__WIFICREDENTIALS_GLOBAL_H__*/