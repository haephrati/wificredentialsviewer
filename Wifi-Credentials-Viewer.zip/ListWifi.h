#pragma once

#include "stdafx.h"
#include "TabPageSSL.h"
#include "afxcmn.h"
#include "easysize.h"
#include "resource.h"
// CListWifi dialog

class CListWifi : public CTabPageSSL
{
	DECLARE_EASYSIZE
	DECLARE_DYNAMIC(CListWifi)

public:
	CListWifi(CWnd* pParent = NULL);   // standard constructor
	virtual ~CListWifi();

// Dialog Data
	enum { IDD = IDD_LIST_WIFI_DLG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	CListCtrl m_WifiListCtrl;
	CImageList m_imageList;			// Image list for the wifi type (either locked or unlocked)
	CDialogEx *m_pParent;
	CBrush m_brush;
	CFont m_font;
	CBrush  m_bkBrush;

private:
	void InitWifiControl();
	void SetTilesViewLinesCount(int nCount);
	void SetTilesViewTileFixedSize();
	void SetItemTileLines(int nItem, UINT* parrColumns, UINT nCount);
public:
	afx_msg void OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized);
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedOk();


	afx_msg void OnPaint();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnNMCustomdrawGrid(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnSizing(UINT fwSide, LPRECT pRect);
	afx_msg void OnBnClickedScan();
	void AddResult(LPWSTR WifiName, LPWSTR WifiKey, LPWSTR HexKey, LPWSTR WifiType);

};
