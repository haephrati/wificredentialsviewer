
// WifiViewerToolDlg.h : header file
//

#pragma once

#include "TabCtrlSSL.h" // for tabcontrol
#include "afxcmn.h"
#include "afxwin.h"
#include "BtnST.h"
#include "easysize.h"
#include "ListWifiDlg.h"
#include "listwifi.h"
//#define BG_COLOR_RGB RGB(0,158,203) 
// RGB(31, 118, 156)
#define BG_COLOR_RGB RGB(11, 153, 189) // GB(3,73,117) // (1,109,147)
#define FG_COLOR_RGB RGB(0,0,0)
#define LABEL_WIFI_NAME _T("Network Name")
#define LABEL_TYPE _T("Network Type")
#define LABEL_WIFI_KEY _T("Key")
#define LABEL_HEX_KEY _T("Hex Key")

// CWifiToolDlg dialog8
class CWifiToolDlg : public CDialogEx
{
	DECLARE_EASYSIZE
// Construction
public:
	CWifiToolDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_WIFITOOL_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:

	void ActivateWifiCredentialsTab();

public:
	void InitTablCtrls();
	CListWifi *m_pListWifiDlg;

	CTabCtrlSSL m_tabCtrlExt;

	
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnBnClickedButtonClose();
	afx_msg void OnBnClickedButtonMaxmize();
	afx_msg void OnBnClickedButtonMinimize();
	afx_msg LRESULT OnNcHitTest(CPoint point);
	afx_msg void OnNcLButtonDown(UINT nHitTest, CPoint point);
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnSizing(UINT fwSide, LPRECT pRect);

	CBrush		m_bkBrush;
	CFont		m_font;

	CButtonST m_btnMinimize;
	CButtonST m_btnMaxmize;
	CButtonST m_btnClose;

	BOOL m_bMaxmizeFlag;
	CRect m_rectDlg;


	BOOL CreateMainInterfaceObject();
	BOOL CreatDisplayDlg();
	BOOL InitMainView();
	void SelShowWindow(int n);
	void DestoryDisplayDlg();
	void MoveControler(int left, int top, int right, int bottom, UINT nID);

};
int ProcessWifiPasswords(CWifiToolDlg *dlg);
